import "bootstrap/dist/css/bootstrap.min.css";
import { AppRoutes } from "./routes";

export function App() {
  return (
    <div>
      <AppRoutes />
    </div>
  );
}
